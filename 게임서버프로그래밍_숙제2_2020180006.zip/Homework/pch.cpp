#include "pch.h"

SOCKET gSocket = INVALID_SOCKET;