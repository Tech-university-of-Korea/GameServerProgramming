#pragma once

#include <WS2tcpip.h>

#pragma comment(lib, "ws2_32.lib")

#include <Windows.h>

#include <iostream>
#include <algorithm>

#include "../Common/Utils.h"
#include "../Common/Protocol.h"