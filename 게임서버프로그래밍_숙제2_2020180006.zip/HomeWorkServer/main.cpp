#include "pch.h"
#include "Network.h"

int main(int argc, char** argv)
{
    Network network;
    network.Run();

    std::cout << "���α׷� ����." << std::endl;
}