#include "pch.h"
#include "Network.h"

std::unique_ptr<Network> gNetwork = std::make_unique<Network>();